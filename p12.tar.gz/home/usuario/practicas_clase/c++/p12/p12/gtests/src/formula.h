#ifndef FORMULA_H
#define FORMULA_H

class Formula {
 public:
  static int Bla(int arg1);
};

#endif 
