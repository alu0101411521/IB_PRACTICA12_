#ifndef SQUARE_ROOT_H
#define SQUARE_ROOT_H

double SquareRoot(const double a);

#endif
