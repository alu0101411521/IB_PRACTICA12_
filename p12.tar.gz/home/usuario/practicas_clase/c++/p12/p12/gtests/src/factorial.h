#ifndef FACTORIAL_H
#define FACTORIAL_H

int Factorial(int n);

#endif 
