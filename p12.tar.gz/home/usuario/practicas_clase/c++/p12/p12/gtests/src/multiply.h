#ifndef MULTIPLY_H
#define MULTIPLY_H

class Multiply {
 public:
  static int TwoValues(const int x, const int y);  
};

#endif
