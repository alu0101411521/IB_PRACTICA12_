/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F. de Sande
 * @date 18 Dec 2020
 * @brief Tests Unitarios con la plataforma gtest
 *        Definición de la función bla que devuelve el doble del valor del argumento que recibe
 * @see 
 */

#include "formula.h"

int Formula::Bla(int arg1) {
  return arg1 * 2;
}
