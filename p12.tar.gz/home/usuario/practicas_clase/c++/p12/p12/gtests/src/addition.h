#ifndef ADDITION_H
#define ADDITION_H

class Addition {
 public:
  static int TwoValues(const int x, const int y);  
};

#endif
